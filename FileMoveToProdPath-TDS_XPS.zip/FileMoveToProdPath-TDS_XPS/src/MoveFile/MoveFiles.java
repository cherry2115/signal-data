

package MoveFile;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;







import GetXmlValue.GetDomXml;

public class MoveFiles 
{
	Statement smt=null;
	private String conf=null;
	private String filePath="";
	static Properties prop=null;
	static String path="";
	static String PROPERTIESFILEPATH="";
	static Logger infoLogger = Logger.getLogger("infolog");
	private static boolean conversionFlag=false;
	static String checkResupply="";
	

	
	
public static void main(String[] args) throws InterruptedException,IOException
	//public static int  main(String[] args) throws InterruptedException,IOException
	{
		//infoLogger.info("Version 28-05-2015(1.0)");
		infoLogger.info("Version 03.02.2016(1.0)");
		path=args[0];
		PROPERTIESFILEPATH = args[1];
		checkResupply=args[2];
		System.out.println("Check Resupply:"+checkResupply);

	//path="E:\\OPSBANK-II\\ORDERS\\CreateCAR\\February-2016\\20-02-2016\\7340399_1.zip";
		//PROPERTIESFILEPATH = "D:\\OPSBANK-II\PROPERTIES\CreateCLELE.properties";
//		checkResupply="78";
		 //checkResupply="RESUPPLY";
		
		
	System.out.println("*************IN MOVING TO PRODUCTION JAR****************************");
	System.out.println("************* VERSION MODIFIED DATE 24.03.2016 *********************");
		prop = new Properties();
		try {
			prop.load(new FileInputStream(PROPERTIESFILEPATH));
		} catch (Exception e) {
			infoLogger.info ("File is not load  : "+e);
			System.exit(0);
		}
		
		MoveFiles moveFiles=new MoveFiles();
		PropertyConfigurator.configure(prop.getProperty("LOG_FILE"));
		
		System.out.println("File moving to production path");
		
	
		File srcFile=new File(path);
		
		
		String path45 = moveFiles.unzipFileandMove(srcFile);
		
		
		//infoLogger.info("*********   XML to DAT file conversion tool start processing  **********");
		
		//moveFiles.runDatConversion(path45);
		
		
		
	}

	
	
	public void runDatConversion(String path45) throws IOException
	{
		
		File f = new File(path45);
		infoLogger.info(path45);
		File[] f1 = f.listFiles();
		for(File f2:f1)
		{
			if(f2.isDirectory())
			{
				infoLogger.info(f2.getAbsolutePath());
				infoLogger.info("CONVERSION TOOL IS PROCESSING...................");
				String cmd ="";
				if(path45.toLowerCase().contains("els"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\ELSEVIER\\ELSEVIER.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
					
				}
				else if(path45.toLowerCase().contains("aipew"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\AIPEW\\AIPEW.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("abpel"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\ABPEL\\ABPEL.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				/*else if(path45.toLowerCase().contains("aip"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\AIP\\AIP.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}*/
				else if(path45.toLowerCase().contains("aip-apa"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\AIP-APA\\AIPAPA.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("abpew"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\ABPEW\\ABPEW.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("aip-wbpg"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\BPG\\Wiley_Blackwell_Conversion.bat"+" "+f2.getAbsolutePath()+" 1";
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("bpg"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\BPG\\Wiley_Blackwell_Conversion.bat"+" "+f2.getAbsolutePath()+" 0";
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("aip-bmc"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\AIP-BMC\\AIPBMC_Conversion.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				else if(path45.toLowerCase().contains("bmc"))
				{
					cmd="B:\\OPSBANKII_Tools\\CONVERSION_TOOLS\\BMC\\BMCConversion.bat"+" "+f2.getAbsolutePath();
					conversionFlag = true;
				}
				else
				{
					infoLogger.info("*********  XML to DAT file conversion tool not found for this flow  **********");
				//	break;
				}
			//	infoLogger.info(cmd);
				if(conversionFlag)
				{
					infoLogger.info(cmd);
					String line="";
					boolean errorUnzip=false;
					infoLogger.info("1");
					Process proc = Runtime.getRuntime().exec(cmd);
					infoLogger.info("2");
					BufferedReader	buf = new BufferedReader(new InputStreamReader(proc.getInputStream()));
					infoLogger.info("3");
					while ((line=buf.readLine())!=null)
					{
						//infoLogger.info("");
						if(line.contains("Error"))
						{
							infoLogger.info(line);
							errorUnzip=true;
						} 
						
						infoLogger.info(line);
					}
					if(errorUnzip)
					{
						infoLogger.info("Problem in dat conversion tool");
					}
				}
			}
		}
		if(conversionFlag)
		{
			infoLogger.info("*********   XML to DAT file conversion tool finished processing  **********");
		}
	}
		
	
	private String unzipFileandMove(File file)
	{
			String path12="";
			String extractedFileName ="";
			String movedFlag="";
			File source = new File(file.getAbsolutePath()); 
			String productionPath = prop.getProperty("Production");	
			
			try {
					File zipFile = source;
					extractedFileName = File.separator+ FilenameUtils.getBaseName(zipFile.getName());
					String Source1 = source.toString().substring(0, source.toString().lastIndexOf("\\")+1);
					System.out.println("Source1 : "+Source1);
					unzipFile(zipFile.getAbsolutePath(), Source1+extractedFileName);
					
					GetDomXml gdm = new GetDomXml(Source1+extractedFileName + "\\order\\order.xml");
					String orderFilePath = Source1+extractedFileName + "\\order";
					String orderType = gdm.getValue("order-type", 0); // Getting the value of "order-type" from order.xml
					String sourceId = gdm.getValue("source-id", 0);	// Getting the value of "source-id" from order.xml
					String supplierUnitId = gdm.getValue("supplier-unit-id", 0); // Getting the value of "supplier-unit-id" from order.xml
					supplierUnitId = supplierUnitId.replace("_DPR", "");
					String orderNumber = gdm.getValue("order-id", 0); // Getting the value of "order-id" from order.xml
					int fileCount = gdm.getChildCount("files" , 0 , "pathname");
					
					int instructionCount = gdm.getChildCount("instructions" , 0 , "instruction");
					boolean scopusCar = false;
					String isbnFileName="";
					String inst="";
					for(int i=0; i<instructionCount; i++)
					{
						inst = gdm.getChildValue("instructions", 0, "instruction", i);
						System.out.println("1. "+inst);
						if(inst.equalsIgnoreCase("Create CAR for Books with Unit-type=BATCH"))
						{
							scopusCar=true;
							
							File[] f = new File(Source1+extractedFileName + "\\ItemFile").listFiles();
							
							for(int j=0; j<f.length; j++)
							{
								if(f[j].getName().endsWith(".zip"))
								{
									String extractedPath = f[j].getAbsolutePath().replace(".zip", "");
									unzipFile(f[j].getAbsolutePath(),extractedPath);
									f[j].delete();
									String fileName = extractedPath+"\\sftp\\content-providers\\tho-e\\data\\incoming\\scopusbk";
									
									File isbnPath = new File(fileName);
									if(isbnPath.isDirectory())
									{
										File[] isbnFile = isbnPath.listFiles();
										boolean breakLoop=false;
										for(int k=0; k<isbnFile.length; k++)
										{
											if(isbnFile[k].getName().endsWith(".txt"))
											{
												isbnFileName = isbnFile[k].getName();
												File dest = new File(Source1+extractedFileName + "\\AdditionalItemFile\\"+isbnFile[k].getName());
												if(!dest.exists())
												{
													dest.getParentFile().mkdirs();
												}
												boolean renamed = isbnFile[k].renameTo(dest);
												if(renamed)
												{
													isbnPath.delete();
													FileUtils.deleteDirectory(f[j].getParentFile());
													
													breakLoop=true;
													break;
												}
											}
										}
										if(breakLoop)
										{
											break;
										}
									}
									else
									{
										System.out.println("Scopus CAR recieved but isbn file not found : "+isbnPath.getAbsolutePath());
									}
								}
							}						
							
						}
					}
					
					System.out.println("Order Type : "+orderType);
					System.out.println("Source Id : "+sourceId);
					System.out.println("Supplier Unit Id : "+supplierUnitId);
					System.out.println("Order Id : "+orderNumber);
					System.out.println("File count: "+fileCount);
					
					
		//==================================================================================================================			
					
					
					// Method for finding the total no of specified child node
					String[] fileName = new String[fileCount];
					String[] fileName2 = null;
					boolean abpelzipflag=false;
					boolean errorLogFlag = false;
					ArrayList<String> al = new ArrayList<String>();
					int f_Count = fileCount;
					File[] isbnFilePath = new File(Source1+extractedFileName + "\\AdditionalItemFile").listFiles();
					for(int j=0; j<f_Count; j++)
					{
						if(scopusCar)
						{
							//System.out.println("Scopus order...");
							String repPath = Source1+extractedFileName.substring(1)+"\\";
							System.out.println(repPath);
							String compPath = isbnFilePath[j].getAbsolutePath();
							System.out.println(compPath);
							fileName[j] = compPath.replace(repPath, "").replace("\\", "/");
							System.out.println(fileName[j]);
						}
						else
						{
							//System.out.println("Not a scopus order....");
							fileName[j]= gdm.getChildValue("files", 0, "pathname", j);
							System.out.println(fileName[j]);
						}
						
						
						if(fileCount==1 && fileName[j].startsWith("ItemFile") && fileName[j].endsWith("_1.zip"))
							
						if(fileName[j] != null && fileName[j].contains("errorlog"))
						{
							errorLogFlag = true;
						}
						System.out.println(fileName[j].length());
						if(fileName[j].length() > 0 && (fileName[j].endsWith(".zip") || fileName[j].endsWith(".ZIP")) && !fileName[j].contains("ARTICLE_THOABPEL") && !fileName[j].contains("ARTICLE_THO"))
						{
							getFilePath(Source1+extractedFileName+"\\ItemFile");
							Source1 = filePath.substring(0, filePath.lastIndexOf("\\")+1);
							System.out.println(Source1);
							extractedFileName = filePath.substring(filePath.lastIndexOf("\\")+1);
							System.out.println(extractedFileName);
							if(filePath.length()>0)
							{
								String[] files = new File(filePath).list();
								fileName2 = files;
								fileCount = files.length;
								for(int i=0; i<files.length; i++)
								{
									String fileNnameFromSourceFile ="";

									if(files[i].contains(".x."))
										fileNnameFromSourceFile = files[i].substring(0,files[i].indexOf(".x."));
									else if(files[i].contains("_"))
										fileNnameFromSourceFile = files[i].substring(0,files[i].indexOf("_"));
									if(!al.contains(fileNnameFromSourceFile))
									{
											al.add(fileNnameFromSourceFile);
									}
								}
							
							}
							supplierUnitId = "THO_BPGGEO"+filePath.substring(filePath.lastIndexOf("\\")+1);
						}
						else if(fileName[j].length() > 0 && (fileName[j].endsWith(".zip") || fileName[j].endsWith(".ZIP")) && (fileName[j].contains("ARTICLE_THOABPEL") || fileName[j].contains("ARTICLE_THO")))
						{
							fileName[j] = fileName[j].replace(".zip", "");
							fileName[j] = fileName[j].substring(fileName[j].indexOf("/")+1);
							al.add(fileName[j]);
							abpelzipflag = true;
						}
						else if(fileName[j] != null && fileName[j].length() > 0 && !(fileName[j].endsWith(".xlsx") || fileName[j].endsWith(".XLSX")))
						{
							System.out.println("In pdf and xml formate");
							String[] s1 = fileName[j].split("_");
							String fileNnameFromSourceFile ="";
							int length = s1.length;
							if(s1[length-1]!=null && !s1[0].contains("errorlog"))
							{
								
								if(supplierUnitId.contains("WBPG"))
								{
									
									if(fileName[j].contains("_fta.wml")||fileName[j].contains("_ftp"))
									{
										fileNnameFromSourceFile = s1[length-2];
									}else{
										fileNnameFromSourceFile = s1[length-1].substring(0, s1[length-1].lastIndexOf("."));
									}
								}
								else if(supplierUnitId.contains("BPG"))
								{
									String temp = s1[0]+"_"+s1[1];
									fileNnameFromSourceFile = fileName[j].substring(temp.length()+1, fileName[j].lastIndexOf("."));
								}
								else
								{
									//if(s1[length-1].endsWith(".txt") && s1[length-1].startsWith("AdditionalItemFile") && s1[length-1].contains(isbnFileName))
									if(s1[length-1].contains(isbnFileName) && isbnFileName.length()>0)
									{
										for(int i=0; i<s1.length; i++)
										{
											if(!(s1[i].contains("error")))
											{
												fileNnameFromSourceFile = s1[i];
												System.out.println("ISBN no : "+fileNnameFromSourceFile);
												supplierUnitId = getSupplierId(fileNnameFromSourceFile.substring(fileNnameFromSourceFile.indexOf("/")+1,fileNnameFromSourceFile.indexOf("-")) , "BOOK_VOLISSINFO");
												System.out.println("supplierUnitId : "+supplierUnitId);
												if(supplierUnitId == null || supplierUnitId.length() == 0)
												{
													System.out.println("Recieved Scopus car but supplier unit id is not found in DB : " +supplierUnitId);
													System.exit(0);
												}
											}
										}
									}
									else
									{
										fileNnameFromSourceFile = s1[length-1].substring(0, s1[length-1].lastIndexOf("."));
									}
								}
								
								if(fileNnameFromSourceFile.contains("/"))
								{
									fileNnameFromSourceFile = fileNnameFromSourceFile.substring(0, fileNnameFromSourceFile.indexOf("/"));
								}
							}
							if(!al.contains(fileNnameFromSourceFile))
							{
								if(s1[0].contains("errorlog"))
								{
									al.add("errorlog");
								}
								else
								{
									al.add(fileNnameFromSourceFile);
								}
							}
						}
					}
					if(fileName2 != null)
					{
						fileName = fileName2;
						if(errorLogFlag)
						{
							String[] temp = new String[fileName.length+1];
							
							for(int i=0; i<fileName.length; i++)
							{
								temp[i] = fileName[i];
							}
							temp[temp.length-1] = "AdditionalItemFile/errorlog.txt";
							fileName = temp;
							fileCount = fileName.length;
						}
					}
					
		//==================================================================================================================		
					String contentProvider ="";
					String contentProvider1 = "";
					String jput = "";
					String processType ="";
					String DBTableName = "";
					String stage ="";
					boolean aipFlag=false;
					if(supplierUnitId.startsWith("THO"))
					{
						if(!supplierUnitId.contains("_"))
						{
							if(supplierUnitId.contains("THOCEP"))
							 {
								DBTableName="CEPVOLISSINFO";
								processType= "CEP";
							 }else{
								 DBTableName="VOLISSINFO";
									processType ="INTERNET";
							 }
						}
						else if(supplierUnitId.contains("THO_BPGGEO"))
						{
							supplierUnitId = supplierUnitId.replace("THO_BPGGEO", "");
							DBTableName="WILEYVOLISSINFO";
							processType ="Wiley_Archive";
						}
						else
						{
							contentProvider = supplierUnitId.substring(3, supplierUnitId.indexOf("_"));
							contentProvider1 = contentProvider;
						
							if(contentProvider.equals("BPG"))
							 {
								DBTableName="BPGVOLISSINFO";
								processType ="EFLOW";
							 }
							if(contentProvider.equals("COR"))
							 {
								DBTableName="COR";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("ABPG"))
							 {
								
								DBTableName="ABPGARTICLEINFO";
								processType ="EFLOW";
								contentProvider1 = "BPG";
								
								/*
								 * @author Nagebdra Babu 11.03.2016 start
								 */
								System.out.println("2. "+inst);
								if (inst.contains("Create CAR for Cochrane")) {
								contentProvider1="COC";
								}
								
								
								/****************end *****************/
							 }
							else if(contentProvider.equals("SEG"))
							 {
								DBTableName="SEGARTICLEINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("SEGI"))
							 {
								DBTableName="SEGVOLISSINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("WBPG"))
							 {
								DBTableName="WBPG";
								processType ="AIP";
							 }
							else if(contentProvider.equals("ELS"))
							 {
								DBTableName="ELSVOLISSINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("ABPEW"))
							 {
								DBTableName="ABPEW";
								processType ="AIP";
							 }
							else if(contentProvider.equals("OUP"))
							 {
								DBTableName="OUPVOLISSINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("SPR"))
							 {
								DBTableName="SPRVOLISSINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("ABPEL"))
							 {
								DBTableName="ABPELARTICLEINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("BMCI"))
							 {
								DBTableName="BMCVOLISSINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("BMC"))
							 {
								DBTableName="BMCARTICLEINFO";
								processType ="EFLOW";
							 }
							else if(contentProvider.equals("AIPEW"))
							 {
								DBTableName="AIPEW";
								processType ="AIP";
							 }
							else if(contentProvider.equals("AIP-BMC"))
							{
								DBTableName="AIPBMC";
								processType ="AIP";
							}
							else if(contentProvider.equals("CEP"))
							{
								DBTableName="CEPVOLISSINFO";
								processType ="CONFERENCE";
							}
							else if(contentProvider.equals("SB"))
							{
								DBTableName="BOOK_VOLISSINFO";
								processType ="SCOPUS";
							}
							else if(contentProvider.equals("AIPAPA"))
							{
								DBTableName="AIPAPA";
								processType ="AIP";
							}
							else if(contentProvider.equals("APA"))
							{
								DBTableName="APAVOLISSINFO";
								processType ="EFLOW";
							}
							else if(contentProvider.equals("BMJ"))
							{
								contentProvider1="AIPBMJ";
								DBTableName="AIPBMJ";
								processType ="AIP";
							}
							else if(contentProvider.equals("ABMC"))
							{
								DBTableName="AIPBMC";
								contentProvider1="AIPBMC";//18.11
								processType ="AIP";
							}
							else if(contentProvider.equals("F1000"))
							{
								DBTableName="f1000articleinfo";
								processType ="EFLOW";
							}

						}
					}
					else
					{
						
						if(!(supplierUnitId.startsWith("THO")) || checkInternet())
						{
							DBTableName = "VOLISSINFO";
							processType = "INTERNET";
						}else{
						
						DbConnection(); //Creating the connection				
						String query = "select content_provider, jput, ELEC, CONF from SOURCEREPOSITORY where id='"+sourceId+"'";
						ResultSet rs =null;
						infoLogger.info(query);
						rs  = smt.executeQuery(query);
						rs.next();
						try
						{
							contentProvider = rs.getString("CONTENT_PROVIDER");
							jput = rs.getString("jput");
							processType = rs.getString("ELEC");
							conf = rs.getString("CONF");
						}
						catch(Exception e)
						{
							infoLogger.error("VALUES OF CONTENT_PROVIDER OR JPUT OR ELEC  NOT PRESENT IN DB");
							System.out.println(e.getMessage());
							System.exit(0);
						}
						
						if(contentProvider.toLowerCase().contains("wiley blackwell") || contentProvider.toLowerCase().contains("bpg"))
						{
							if(source.toString().contains("AIP"))
							{
								DBTableName = "WBPG";
								contentProvider1="AIPWBPG";
								processType ="AIP";
							}
							else
							{
								if(jput.equalsIgnoreCase("ISSUE"))
								{
									DBTableName = "BPGVOLISSINFO";
									contentProvider1="BPG";
									processType ="EFLOW";
								}
								else
								{
									System.exit(0);
								}
							}
							
						}
						else if(contentProvider.toLowerCase().contains("elsevier"))
						{
							if(source.toString().contains("AIP"))
							{
								if(stage.equals("S200"))
								{
									DBTableName = "ABPEW";
									contentProvider1 = "ABPEW";
								}
								else
								{
									DBTableName = "AIPEW";
								}
							}
							else 
							{	
								if(jput.equals("ISSUE"))
								{
									DBTableName = "ELSVOLISSINFO";
									contentProvider1 = "ELS";
								}
								else
								{
									DBTableName = "ABPELARTICLEINFO";
									contentProvider1 = "ABPEL";
								}
							}
							
						}
						else if(contentProvider.toLowerCase().contains("oxford university press") || contentProvider.equalsIgnoreCase("oup"))
						{
							if(jput.equals("ISSUE"))
							{
								DBTableName = "OUPVOLISSINFO";
								contentProvider1 = "OUP";
							}
							else
							{
								System.exit(0);
							}
						}
						else if(contentProvider.toLowerCase().contains("american psychological association") || contentProvider.toLowerCase().contains("apa"))
						{
							
							if(source.toString().contains("AIP"))
							{
								
									DBTableName = "AIPAPA";
									contentProvider1 = "AIPAPA";
									processType ="INTERNET";
							}
							else
							{
								if(jput.equals("ISSUE"))
								{
									DBTableName = "APAVOLISSINFO";
									contentProvider1 = "APA";
									processType ="INTERNET";
								}
								else
								{
									System.exit(0);
								}
							}
						}
						else if(contentProvider.toLowerCase().contains("springer publishing company"))
						{
							if(jput.equals("ISSUE"))
							{
								DBTableName = "SPRLVOLISSINFO";
								contentProvider1 = "SPR";
								processType ="EFLOW";
							}
							else
							{
								System.exit(0);
							}
						}
						else if(contentProvider.equalsIgnoreCase("aip") || contentProvider.toLowerCase().contains("american institute of physics"))
						{
							if(jput.equalsIgnoreCase("ARTICLE"))
							{
								DBTableName = "AIPARTICLEINFO";
								contentProvider1 = "AIP";
								processType ="EFLOW";
							}
							else
							{
								System.exit(0);
							}
						}
						else if(contentProvider.toLowerCase().contains("asme") || contentProvider.equalsIgnoreCase("American Society of Mechanical Engineers"))
						{
							if(jput.equalsIgnoreCase("ARTICLE"))
							{					
								DBTableName = "ASMEARTICLEINFO";
								contentProvider1 = "ASME";
								processType ="EFLOW";
							}
							else
							{
								System.out.println("We are going to process Article only....");
								System.exit(0);
							}
						}
						else if(contentProvider.toLowerCase().contains("biomed central") || contentProvider.equalsIgnoreCase("bmc"))
						{
							
							if(source.toString().contains("AIP"))
							{
									DBTableName = "AIPBMC";
									contentProvider1 = "AIPBMC";
									processType ="AIP";
							}
							else
							{
								if(jput.equalsIgnoreCase("ARTICLE"))
								{	
									DBTableName = "BMCARTICLEINFO";
									contentProvider1 = "BMC";
									processType ="EFLOW";
								}
								else
								{
									System.exit(0);
								}
							}
						}
						else if(contentProvider.toLowerCase().contains("mit press"))
						{
							DBTableName = "VOLISSINFO";
							contentProvider1 = "MIT";
							processType = "INTERNET";
						}
						else if(contentProvider.toLowerCase().contains("asce"))
						{
							DBTableName = "VOLISSINFO";
							contentProvider1 = "ASCE";
							processType = "INTERNET";
						}
						else if(contentProvider.toLowerCase().contains("iet") || contentProvider.contains("Institution of Engineering and Technology"))
						{
							DBTableName = "VOLISSINFO";
							contentProvider1 = "IET";
							processType = "INTERNET";
						}
						else if(contentProvider.toLowerCase().contains("society of exploration geophysicists"))
						{
							DBTableName = "VOLISSINFO";
							processType = "INTERNET";
						}
						else if(contentProvider.toLowerCase().contains("optical society of america"))
						{
							DBTableName = "CONF_MASTER";
							processType = "INTERNET";
						}
						else if(contentProvider.toLowerCase().contains("bmj publishing group"))
						{				
							if(source.toString().contains("AIP"))
							{
								DBTableName = "AIPBMJ";
								contentProvider1 = "BMJ";
								processType = "INTERNET";
							}					
						}
						else if(processType.toLowerCase().contains("internet"))
						{	
							DBTableName = "VOLISSINFO";
							processType = "INTERNET";
						}
						else if(conf.equalsIgnoreCase("CONFOPT") || conf.equalsIgnoreCase("CONFREQ"))
						{				
							DBTableName = "CEPVOLISSINFO";
							processType = "EFLOW";
							contentProvider1 = "CEP";
						}
						else if(contentProvider.toLowerCase().contains("bmj publishing group"))
						{	
								DBTableName = "AIPBMJ";
								contentProvider1 = "BMJ";
								processType = "INTERNET";
												
						}
						else if(contentProvider.toLowerCase().contains("Faculty of 1000 Ltd"))
						{
								DBTableName = "f1000articleinfo";
								contentProvider1 = "F1000";
						}
						else
						{
							
							DBTableName = "VOLISSINFO";
							processType = "INTERNET";
							/*infoLogger.info("Content Provider is not found in DB");
							FileUtils.forceDelete(new File(Source1+extractedFileName));
							System.exit(0) ;*/
						}
					} //if	
						
				}//Faculty of 1000 Ltd       
					
					//System.out.println("Content provider---->"+contentProvider+"\tTableName---->"+DBTableName+"\tContentProvider1---->"+contentProvider1);
					DateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yy");
					Calendar cal1 = Calendar.getInstance();
					String sdate1 = dateFormat1.format(cal1.getTime());
					
					System.out.println("Table Name:"+DBTableName);
					DbConnection();
					String Batch = "";
					String SUPPLIERUNITIDFROMDB = "";
					String queryforbatch = "select BATCH, SUPPLIERUNITID from "+DBTableName+" where SUPPLIERUNITID = '"+supplierUnitId+"'";
					System.out.println(queryforbatch);
					//System.exit(0);
					ResultSet rs  = smt.executeQuery(queryforbatch);
					if(rs.next())
					{
						System.out.println("Check Resupply -----"+checkResupply);
						if(checkResupply.equalsIgnoreCase("RESUPPLY"))
						{
							infoLogger.info("GET THE BATCH FROM RESUPPLY TABLE.....");
							String zipname=path.substring(path.lastIndexOf("\\")+1);
							System.out.println(zipname);
							Statement smt=DbConnection1();
							String queryforbatch1 = "select BATCH from RESUPPLY where ZIPNAME = '"+zipname+"'";
							ResultSet rs1  = smt.executeQuery(queryforbatch1);
							if(rs1.next())
							Batch=rs1.getString("BATCH");
						}
						else
						{
							Batch = rs.getString("BATCH");
							System.out.println("Batch---->"+Batch);
						}
						SUPPLIERUNITIDFROMDB = rs.getString("SUPPLIERUNITID");
					}
					if(!(SUPPLIERUNITIDFROMDB.length() > 0))
					{
						Batch = sdate1;
					}
					
					String yearFromBatch="";
					String monthFromBatch ="";
					try
					{
						yearFromBatch = Batch.substring(Batch.lastIndexOf(".")+1, Batch.length());
						if(yearFromBatch.length()==2)
							yearFromBatch = "20"+yearFromBatch;
						monthFromBatch = Batch.substring(Batch.lastIndexOf(".")-2, Batch.lastIndexOf("."));
						//System.out.println("Year---->"+yearFromBatch+"\tMonth---->"+monthFromBatch);
					}
					catch(Exception e)
					{
					infoLogger.info("BATCH DATE FORMATE IS NOT MATCH");
					}
					
					
					if(monthFromBatch.equals("01"))
					{
						monthFromBatch = "JANUARY";
					}
					else if(monthFromBatch.equals("02"))
					{
						monthFromBatch = "FEBRUARY";
					}
					else if(monthFromBatch.equals("03"))
					{
						monthFromBatch = "MARCH";
					}
					else if(monthFromBatch.equals("04"))
					{
						monthFromBatch = "APRIL";
					}
					else if(monthFromBatch.equals("05"))
					{
						monthFromBatch = "MAY";
					}
					else if(monthFromBatch.equals("06"))
					{
						monthFromBatch = "JUNE";
					}
					else if(monthFromBatch.equals("07"))
					{
						monthFromBatch = "JULY";
					}
					else if(monthFromBatch.equals("08"))
					{
						monthFromBatch = "AUGUST";
					}
					else if(monthFromBatch.equals("09"))
					{
						monthFromBatch = "SEPTEMBER";
					}
					else if(monthFromBatch.equals("10"))
					{
						monthFromBatch = "OCTOBER";
					}
					else if(monthFromBatch.equals("11"))
					{
						monthFromBatch = "NOVEMBER";
					}
					else if(monthFromBatch.equals("12"))
					{
						monthFromBatch = "DECEMBER";
					}
					else
					{
						infoLogger.info("NOT A VALID MONTH : "+monthFromBatch);
						System.exit(0);
					}
					//System.out.println("Now Month---->"+monthFromBatch);
					String restProductionPath ="";					
					if(processType.equals("INTERNET"))
					{
						//restProductionPath = processType + "\\"+ orderType + "\\" + monthFromBatch + "-" + yearFromBatch + "\\" + "Batch_" + Batch + "\\" + orderNumber + "\\";
						
						StringBuilder stringBuilder = new StringBuilder();
						stringBuilder.append(processType);
						stringBuilder.append("\\");
						if(orderType.contains("RESUPPLY"))
						{
							stringBuilder.append("RESUPPLY");
						}
						else
						{
							stringBuilder.append(orderType);
						}
						stringBuilder.append("\\");
						stringBuilder.append(monthFromBatch);
						stringBuilder.append("-");
						stringBuilder.append(yearFromBatch);
						stringBuilder.append("\\");
						stringBuilder.append("Batch_");
						stringBuilder.append(Batch);
						stringBuilder.append("\\");
						stringBuilder.append(orderNumber);
						stringBuilder.append("\\");
						
						restProductionPath = stringBuilder.toString();
					}		
					else 
					{
						if(checkResupply.equalsIgnoreCase("RESUPPLY")){
							restProductionPath =processType + "\\"+ "RESUPPLY" + "\\" + contentProvider1 + "\\" + monthFromBatch + "-" + yearFromBatch + "\\" + "Batch_" + Batch + "\\" + orderNumber + "\\";	
						}
						else if(processType.equals("SCOPUS")){
							restProductionPath =processType + "\\"+ orderType + "\\" + monthFromBatch + "-" + yearFromBatch + "\\" + "Batch_" + Batch + "\\" + orderNumber + "\\";
						}
						
						
						/****            20.11  START          ****/
						else if(processType.equals("CONFERENCE"))
						{
							restProductionPath ="CEP\\"+ orderType + "\\" + monthFromBatch + "-" + yearFromBatch + "\\" + "Batch_" + Batch + "\\" + orderNumber + "\\";
						}
						/****            20.11   END	     ****/
						
						
						else
						{
							restProductionPath =processType + "\\"+ orderType + "\\" + contentProvider1 + "\\" + monthFromBatch + "-" + yearFromBatch + "\\" + "Batch_" + Batch + "\\" + orderNumber + "\\";
							System.out.println("ProductionPath: "+restProductionPath);
						}
						//System.out.println("Rest production path---->"+restProductionPath);
					}
					if(!productionPath.endsWith("\\"))
					{
						productionPath = productionPath+"\\";
						//System.out.println("Production path---->"+productionPath);
					}
					Iterator<String> itr = al.iterator();	
					
					
					path12 = productionPath + restProductionPath;
					//System.out.println("Path12---->"+path12);
					
					if(new File(productionPath).exists())
					{
						infoLogger.info("Path exists... Order can be moved to production path... ");;
							//Thread.sleep(5000);
						
					while (itr.hasNext()) 
					{
						String str = itr.next();
						String finalProductionPath = productionPath + restProductionPath + str;
						//System.out.println("Final Production path---->"+finalProductionPath);
						int a = 0;
							
						if(processType.equals("EFLOW"))
						{
							if(orderType.equals("CAR-RESUPPLY"))
							{
								finalProductionPath = productionPath+restProductionPath + str;
								//System.out.println("Final Production path---->"+finalProductionPath);
							}
							else if(!orderType.equals("CAR"))
							{
								finalProductionPath = productionPath+restProductionPath;
								//System.out.println("Final Production path---->"+finalProductionPath);
							}		
							
						}
						//18.11
						else if(processType.equals("AIP"))
						{
							finalProductionPath = productionPath + restProductionPath;
							aipFlag=true;
							
						}//18.11
						//System.out.println("Final Production path---->"+finalProductionPath);
						File f = new File(finalProductionPath);
						if(!f.isDirectory())
						{
							if(!f.toString().endsWith("HT"))
							f.mkdirs();
						}					
						while (a < fileCount) {
							if (fileName[a].contains(str) || fileName[a].endsWith(".xlsx") || fileName[a].endsWith(".XLSX"))
							{
								if(processType.equals("INTERNET") && !abpelzipflag)
								{
									String splitFile="";
									if(contentProvider1.equalsIgnoreCase("iet"))
									{
										
										splitFile=fileName[a].substring(fileName[a].lastIndexOf("-"),fileName[a].lastIndexOf("."));
										if(fileName[a].toString().endsWith(".xml"))
										{
											str = str+"_HT";
										}
										infoLogger.info("sPLITfILE:"+splitFile);
										if(str.contains(splitFile))
										{
											String currentFileProductionPath = finalProductionPath+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());
											String currentFileSourcePath = Source1+extractedFileName+"\\"+fileName[a];
											//System.out.println("1.Cur file prod path---->"+currentFileProductionPath+"\tCur file src path---->"+ currentFileSourcePath );
											infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
											FileUtils.copyFile(new File(currentFileSourcePath) , new File(currentFileProductionPath));
										}
									}
									else
									{
										if(fileName[a].contains("AdditionalItemFile"))
										{
											splitFile=fileName[a].trim().substring(0,fileName[a].lastIndexOf("/"));
										}
										else
										{
											splitFile=fileName[a].substring(fileName[a].lastIndexOf("_")+1,fileName[a].lastIndexOf("."));
										}
										if(splitFile.equals(str))
										{
											String currentFileProductionPath = finalProductionPath+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());
											String currentFileSourcePath = Source1+extractedFileName+"\\"+fileName[a];
											//System.out.println("2.Cur file prod path---->"+currentFileProductionPath+"\tCur file src path---->"+ currentFileSourcePath );
											infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
											FileUtils.copyFile(new File(currentFileSourcePath) , new File(currentFileProductionPath));
										}
									}
								}else{
									String currentFileProductionPath = finalProductionPath+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());
									String currentFileSourcePath = "";
									if(supplierUnitId.equalsIgnoreCase(extractedFileName) && fileName[a].contains("errorlog"))
									{
										currentFileSourcePath = zipFile.getAbsolutePath().substring(0, zipFile.getAbsolutePath().lastIndexOf("."))+"\\"+fileName[a];
									}
									else
									{
										currentFileSourcePath = Source1+extractedFileName+"\\"+fileName[a];
									}
									//infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
									
									if(abpelzipflag)
									{
										currentFileSourcePath = currentFileSourcePath.replace(fileName[a], "ItemFile\\"+fileName[a]);
										//System.out.println("3.Cur file prod path---->"+currentFileProductionPath+"\tCur file src path---->"+ currentFileSourcePath );
										infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
										FileUtils.copyDirectory(new File(currentFileSourcePath) , new File(currentFileProductionPath.substring(0,currentFileProductionPath.lastIndexOf("\\"))));
									}
									else
									{
										if(aipFlag)
										{
											System.out.println("For AIP...");
											
											String sql="";
											if(DBTableName.equals("AIPEW"))
											{
												sql="select zipname from "+DBTableName+" where car_orderid='"+orderNumber+"'";
											}
										//18.11
											else
											{
												sql="select filename from "+DBTableName+" where car_orderid='"+orderNumber+"'";
											}
											String folderName="";
											Statement stmt=DbConnection1();
											ResultSet rsltSet=stmt.executeQuery(sql);
//											System.out.println("sql Query:"+sql);
											if(rsltSet.next())
											{
												folderName=rsltSet.getString(1);
											}
											//System.out.println("fOLDER name------->>>"+folderName);
											if(folderName.endsWith(".xml"))
											{
												folderName=folderName.replace(".xml","");
											}
											else if(folderName.endsWith(".pdf"))      //07-03-2016 for creating without .pdf files.
											{
												folderName=folderName.replace(".pdf","");
											}
											//System.out.println("FileName->"+folderName);
											//System.out.println(finalProductionPath);
											//String tmp=finalProductionPath+"\\"+folderName+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());;
											currentFileProductionPath=finalProductionPath+"\\"+folderName+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());
											System.out.println("current file production path:::::>>>"+currentFileProductionPath);
											//System.out.println("New Created:-->"+tmp);
											//System.out.println("4.Cur file prod path---->"+currentFileProductionPath+"\tCur file src path---->"+ currentFileSourcePath );
//										     //System.out.println("fILE COPING TO PRODUCTION PATG--------PLEASE WAIT--------@@@@");
											infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
											FileUtils.copyFile(new File(currentFileSourcePath) , new File(currentFileProductionPath));
										}
										else
										{
											infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
											FileUtils.copyFile(new File(currentFileSourcePath) , new File(currentFileProductionPath));
											
										}
									}

								}
							}
							
							else if (fileName[a].contains(str) || fileName[a].endsWith(".zip") || fileName[a].endsWith(".ZIP")) 
							{
								String currentFileProductionPath = finalProductionPath+"\\"+fileName[a].substring(fileName[a].lastIndexOf("/")+1, fileName[a].length());
								
								String currentFileSourcePath = Source1+extractedFileName+"\\"+fileName[a];
								//System.out.println("5.Cur file prod path---->"+currentFileProductionPath+"\tCur file src path---->"+ currentFileSourcePath );
								infoLogger.info("File Coping to production path .....Please wait......."+currentFileProductionPath);
								FileUtils.copyFile(new File(currentFileSourcePath) , new File(currentFileProductionPath));
								unZip(currentFileProductionPath,finalProductionPath);
								FileUtils.forceDelete(new File(currentFileProductionPath));
							}
							
							a++;
						}
						if(!new File(finalProductionPath.substring(0, finalProductionPath.lastIndexOf("\\"))+"\\order.xml").exists())
						{
							FileUtils.copyFile(new File(orderFilePath+"\\order.xml"), new File(finalProductionPath.substring(0, finalProductionPath.lastIndexOf("\\"))+"\\order.xml"));
							//System.out.println("Order file path---->"+orderFilePath+"\tfinalProductionPath---->"+finalProductionPath);
						}
					}
					
					String orderZipPath = orderFilePath.substring(0, orderFilePath.lastIndexOf("\\"))+".zip";
					String processedFolderPath = orderFilePath.substring(0, orderFilePath.lastIndexOf("\\"));
					processedFolderPath = processedFolderPath.substring(0, processedFolderPath.lastIndexOf("\\"))+"\\PROCESSED";
					String fileNameZip = orderZipPath.substring(orderZipPath.lastIndexOf("\\"));
					String fileNameReady = fileNameZip.substring(0,fileNameZip.indexOf("_"))+".ready.xml";
					String readyFilepath = orderZipPath.substring(0, orderZipPath.lastIndexOf("_"))+".ready.xml";
					if(!new File(processedFolderPath).exists())
					{
						new File(processedFolderPath).mkdirs();
					}
					File processedPathZip = new File(processedFolderPath+"\\"+fileNameZip);
					
					//System.out.println("Zip is moving into the folder------>"+processedPathZip.toString());
					
					File processedPathReady = new File(processedFolderPath+"\\"+fileNameReady);
					
					//System.out.println("Ready.xml is moving into the folder------>"+processedPathReady.toString());
					
					if(processedPathZip.exists())
					{
						processedPathZip.delete();
					}
					if(processedPathReady.exists())
					{
						processedPathReady.delete();
					}
					new File(orderZipPath).renameTo(processedPathZip);
					infoLogger.info("Files copied successfully : "+processedPathZip.getAbsolutePath());
					new File(readyFilepath).renameTo(processedPathReady);
					infoLogger.info("Files copied successfully : "+processedPathReady.getAbsolutePath());	
					
					System.out.println("In td-xps File path for :" + path12);//--> Td-XPS
					System.out.println("AND ordernumber:"+orderNumber+"    TableName:"+DBTableName+"  And orderType is :"+orderType);
					if(new File(path12).exists())
					{
						infoLogger.info("File is moved to production path properly.....Gonna change status.. ");
						changeStatus(orderNumber,DBTableName);
						updateOrderinfo(orderType,orderNumber);
						//TDS_XPS MARKER CREATION 
						File tdsFile = new File(path12);
						File[] tdsFilesList = tdsFile.listFiles();
						for (int i = 0; i < tdsFilesList.length; i++) {
							if (tdsFilesList[i].isDirectory()) {
								markerForTDS_XPS(tdsFilesList[i].toString(),orderNumber);
							}
						}
						//TDS_XPS MARKER CREATION 
					}
					else
					{
						infoLogger.error("Error in moving file...");
					}
					if(processedPathZip.exists()&&processedPathReady.exists())
					{
						infoLogger.info("File is moved into processed folder properly.....");
					}
					else
					{
						infoLogger.info("Error in moving to processed folder......");
					}
					}
					else
					{
						infoLogger.error("Path does not exist....******* Moving to Failed folder.... And check mail...");
						String orderZipPath = orderFilePath.substring(0, orderFilePath.lastIndexOf("\\"))+".zip";
						String failedFolderPath = orderFilePath.substring(0, orderFilePath.lastIndexOf("\\"));
						failedFolderPath = failedFolderPath.substring(0, failedFolderPath.lastIndexOf("\\"))+"\\FAILED";
						String fileNameZip = orderZipPath.substring(orderZipPath.lastIndexOf("\\"));
						String fileNameReady = fileNameZip.substring(0,fileNameZip.indexOf("_"))+".ready.xml";
						String readyFilepath = orderZipPath.substring(0, orderZipPath.lastIndexOf("_"))+".ready.xml";
						
						
						if(!new File(failedFolderPath).exists())
						{
							new File(failedFolderPath).mkdirs();
							//System.out.println("Failed folder path----->"+failedFolderPath);
						}
						File failedPathZip = new File(failedFolderPath+"\\"+fileNameZip);
						
						//System.out.println("Zip is moving into the folder------>"+processedPathZip.toString());
						
						File failedPathReady = new File(failedFolderPath+"\\"+fileNameReady);
						
						//System.out.println("Ready.xml is moving into the folder------>"+processedPathReady.toString());
						
						if(failedPathZip.exists())
						{
							failedPathZip.delete();
						}
						if(failedPathReady.exists())
						{
							failedPathReady.delete();
						}
						new File(orderZipPath).renameTo(failedPathZip);
						infoLogger.info("Orders moved to Failed folder: "+failedPathZip.getAbsolutePath());
						new File(readyFilepath).renameTo(failedPathReady);
						infoLogger.info("Orders moved to failed folder: "+failedPathReady.getAbsolutePath());		
						updateRemark(orderNumber);
						sendEmail(orderNumber,failedFolderPath);
						//sendEmail1(orderNumber,failedFolderPath);//for testing
						System.exit(0);
					}
			
				
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				System.exit(0);
			}
			//return path12;
			return movedFlag;
	}
	

	
	private String getSupplierId(String isbn , String tableName) {
		DbConnection();
		String qry = "select SUPPLIERUNITID from "+tableName+" where PRINT_ISBN='"+isbn+"'";
		try {
			ResultSet rs = smt.executeQuery(qry);
			if(rs.next())
			{
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}
	private void getFilePath(String string) {

		File f = new File(string);
		if(f.isDirectory())
		{
			File[] f2 = f.listFiles();
			for(int i=0; i<f2.length; i++)
			{
				if(f2[i].isDirectory())
				{
					getFilePath(f2[i].getAbsolutePath());
				}
				else if(!f2[i].getAbsolutePath().endsWith(".zip"))
				{
					filePath = f2[i].getParent();
					break;
				}
			}
		}
		else
		{
			if(!f.getAbsolutePath().endsWith(".zip"))
			{
				filePath = f.getParent();
			}
		}
	}
	public  boolean unZip(String paths,String a) 
	{
			String line="";
			boolean errorUnzip=false;
			try {
				String zip_path=(paths.substring(0,paths.lastIndexOf("\\"))).trim();
				String	cmd=("7z x "+paths+" -o"+a+" -y");
				Process proc = Runtime.getRuntime().exec(cmd);
				BufferedReader	buf = new BufferedReader(new InputStreamReader(proc.getInputStream()));
				while ((line=buf.readLine())!=null)
				{
					if(line.contains("Error"))
					{
						errorUnzip=true;
					}                                                   
				}
				
			} catch (IOException e) {
			infoLogger.error("Problem in unZip() method --->  "+e.getMessage());
			}
		return errorUnzip;
	}
	
	private void DbConnection()
	{
		try {			
			Class.forName("com.mysql.jdbc.Driver");
			//String dbURL ="jdbc:mysql://10.10.10.14:3306/OPSBANK-II";
			String dbURL =prop.getProperty("URL");//"jdbc:mysql://10.10.11.27:3306/OPSBANK-II";
		     String user = prop.getProperty("USERNAME");//"root";
		     String pass = prop.getProperty("PASSWORD");//"p@ssw0rd";
		     
		     
		    /*Class.forName("com.mysql.jdbc.Driver");
			 String dbURL ="jdbc:mysql://localhost:3306/OPSBANK-II";
		     String user = "root";
		     String pass = "root";*/
		     
		     
		     Connection con = DriverManager.getConnection(dbURL, user, pass);

				
				smt = con.createStatement();			
			}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	private Statement DbConnection1()
	{
		try {			
			 Class.forName("com.mysql.jdbc.Driver");
			//String dbURL ="jdbc:mysql://10.10.10.14:3306/OPSBANK-II";
			 String dbURL =prop.getProperty("URL");//"jdbc:mysql://10.10.11.27:3306/OPSBANK-II";
		     String user = prop.getProperty("USERNAME");//"root";
		     String pass = prop.getProperty("PASSWORD");//"p@ssw0rd";
		     
		    /* Class.forName("com.mysql.jdbc.Driver");
			 String dbURL ="jdbc:mysql://localhost:3307/OPSBANK-II";
		     String user = "root";
		     String pass = "root";*/
		     Connection con = DriverManager.getConnection(dbURL, user, pass);
			
			smt = con.createStatement();			
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return smt;
	}

	public boolean checkInternet()
	{
		boolean flag=true;
		
		String orderItemFile1=path.substring(0,path.lastIndexOf("."));
		String orderItemFile=orderItemFile1+"\\ItemFile";
		
		File itemPath=new File(orderItemFile);
		
		File[] file=itemPath.listFiles();
		
		for(File file1:file)
		{
			if(file1.getName().endsWith(".xml"))
			{
				flag=false;
				break;
			}
		}
				
		return flag;
		
	}
	
	private void unzipFile(String filePath, String outputFolder){

		byte[] buffer = new byte[1024];

		try{
			//get the zip file content
			ZipInputStream zis = 
					new ZipInputStream(new FileInputStream(filePath));
			//get the zipped file list entry
			ZipEntry ze = zis.getNextEntry();
			File newFile=null;
			while(ze!=null){
				if(!ze.isDirectory())
				{
				String fileName = ze.getName();
				 newFile = new File(outputFolder + File.separator + fileName);
				}else{
					String fileName = ze.getName();
					 newFile = new File(outputFolder + File.separator + fileName);
					 newFile.mkdirs();
					 ze = zis.getNextEntry();
					 continue;
				}
				infoLogger.info("file unzip : "+ newFile.getAbsoluteFile());
				//create all non exists folders
				//else you will hit FileNotFoundException for compressed folder
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				 if(newFile.getAbsolutePath().endsWith(".zip"))
				 {
					 unzipFile(newFile.getAbsolutePath(), newFile.getAbsolutePath().substring(0, newFile.getAbsolutePath().lastIndexOf(".")));
				 }
				ze = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();
			infoLogger.info("Unzipping Done");		
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	static void sendEmail(String orderId,String  path)
	{
		
		System.out.println("Sending Email.......");
		String cc3="sainarasimhanr@thomsondigital.com";
		String to2="rohit.c@thomsondigital.com";
		String to3=" subrata.das@thomsondigital.com";
		String cc4 = "dhahini.devi@thomsondigital.com";
		String to1 = "d.kathiresan@thomsondigital.com";
		String cc2 = "arumugam.paramasivan@thomsondigital.com";
		String cc1 = "a.karthikeyan@thomsondigital.com";
				
		String from = "EOPS-SOFTWARE";
		String host = "202.54.251.85";
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);
		try
		{
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));   
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to1));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to3));
		message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc1));
		message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc2));
		message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc3));
		message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc4));
		message.setSubject("Reg: Moving Files to Production Path "); 
		
		
		MimeBodyPart mailContent= new MimeBodyPart();
		String  msgContent="<p style=\"font-family:calibri;font-size:14\"><b>Dear Sir,</b>";
		msgContent+="<br><br>Following is the file that cannot be moved to Production path due to some network issues and hence moved to Failed Folder.<br><br>"+orderId;
		msgContent+="<br><br>Find those files in the path given below.";
		msgContent+="<br><b>"+path+"</b>";
		msgContent+="<br><br><b>Regards,<br>Software .</b></br></p>";
		msgContent+="<p style=\"font-family:calibri;color:red;font-size:14\">Warning: Please take immediate action. If not, file will be moved to backup.</p>";
		msgContent+="<p style=\"font-family:calibri;color:gray;font-size:14\">Note: Please do not reply. This is an auto-generated mail.</p>";
		
	//	System.out.println("Mail content is--->"+msgContent);
	
		Multipart multipart = new MimeMultipart();  
		
		mailContent.setContent(msgContent,"text/html");
	   
	    
	    multipart.addBodyPart(mailContent);

	    message.setContent(multipart );
	    Transport.send(message);
	
	    System.out.println("\n\nEmail is sent to concerned departments....");
		}
		catch(MessagingException me)
		{
			System.out.println(me);
		}
	}
	
	
	//for testing mail
	
	static void sendEmail1(String orderId,String  path)
	{
		
		System.out.println("Sending Email.......");
		String to1 = "dhahini.devi@thomsondigital.com";
		
				
		String from = "EOPS-SOFTWARE";
		String host = "202.54.251.85";
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);
		try
		{
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));   
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to1));
		//message.addRecipient(Message.RecipientType.TO, new InternetAddress(to2));
		//message.addRecipient(Message.RecipientType.TO, new InternetAddress(to3));
		//message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc1));
		//message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc2));
		//message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc3));
		message.setSubject("Reg: Moving Files to Production Path "); 
		
		
		MimeBodyPart mailContent= new MimeBodyPart();
		String  msgContent="<p style=\"font-family:calibri;font-size:14\"><b>Dear Sir,</b>";
		msgContent+="<br><br>Following is the file that cannot be moved to Production path due to some network issues and hence moved to Failed Folder.<br><br>"+orderId;
		msgContent+="<br><br>Find those files in the path given below.";
		msgContent+="<br><b>"+path+"</b>";
		msgContent+="<br><br><b>Regards,<br>Software .</b></br></p>";
		msgContent+="<p style=\"font-family:calibri;color:red;font-size:14\">Warning: Please take immediate action. If not, file will be moved to backup.</p>";
		msgContent+="<p style=\"font-family:calibri;color:gray;font-size:14\">Note: Please do not reply. This is an auto-generated mail.</p>";
		
	//	System.out.println("Mail content is--->"+msgContent);
	
		Multipart multipart = new MimeMultipart();  
		
		mailContent.setContent(msgContent,"text/html");
	   
	    
	    multipart.addBodyPart(mailContent);

	    message.setContent(multipart );
	    Transport.send(message);
	
	    System.out.println("\n\nEmail is sent to concerned departments....");
		}
		catch(MessagingException me)
		{
			System.out.println(me);
		}
	}
	
	//Method to update status once moved to production folder....26-10
	
	public void changeStatus(String orderid,String tableName) throws SQLException
	{
		Statement smt=DbConnection1();
		//tableName=tableName+"_copy";
		String query="update "+tableName+" set status='RECEIVED' where car_orderid='"+orderid+"'";
		System.out.println("Query-->"+query);
		
		int status=smt.executeUpdate(query);
		System.out.println("Updating status=-=->"+status);
		if(status>=1)
		{
			System.out.println("Status is changed to RECEIVED.");
		}
		else
		{
			System.out.println("Error in updating...");
		}
	}
	public void updateRemark(String orderId) throws SQLException
	{
		Statement smt=DbConnection1();
		String query="update orderinfo set remark='Network Issue: File moved to failed folder'  where orderid='"+orderId+"'";
		System.out.println(query);
		smt.execute(query);
	}
	
	public void updateOrderinfo(String orderType,String orderId) throws SQLException
	{
		Statement smt=DbConnection1();
		//update orderid,ordertype,flow,status where ordername=zipname;
		String query="update orderinfo set status='"+orderType+" CREATED'  where orderid='"+orderId+"'";
		System.out.println(query);
		smt.execute(query);
	}
	//TDS_XPS MARKER CREATION 
	private void markerForTDS_XPS(String path, String ordernumber) {
		String markerpath = prop.getProperty("TdsXps_Marker");
		System.out.println("Marker path for tds_Xps::" + markerpath);
		try {
			File tdsXpsPath = new File(markerpath);
			if (!tdsXpsPath.exists()) {
				tdsXpsPath.mkdirs();
			}
			// path="~"+path;
			String path2 = path.replace("\\", "~");
			path2 = path2.replace(":", "");
			//System.out.println(" Replaced path::" + path2);
			File f = new File(markerpath + "\\" + path2 + ".ini");
			System.out.println("Marker path::" + f);

			f.createNewFile();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	//TDS_XPS MARKER CREATION 

}