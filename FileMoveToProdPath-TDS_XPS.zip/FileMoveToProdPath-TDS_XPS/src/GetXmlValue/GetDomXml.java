package GetXmlValue;


import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.log4j.Logger;
import org.w3c.dom.*;

public class GetDomXml {

	private Document m_doc;
	static Logger log = Logger.getLogger(GetDomXml.class.getName());
	static String xmlfile = "";
	public static void main(String[] args) {
		// For testing
		try {
			//log.info("parsing XML   D:\\conversion\\011704_1.xml");
			GetDomXml domxml = new GetDomXml("D:/OPSBANK-II/ORDERS/CLWEB/74526_1/ItemFile/CL_THO14092600056.xml");
			String  s = domxml.getAttributeValue("unit", 0, "type"); // getAttributeValuewithvar4
			System.out.println("*");
			System.out.println(s);
			}    
		catch (Exception e) {
			//log.error(e);
		}
	}

	public GetDomXml(String xmlfile) throws Exception 
	{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		m_doc = builder.parse(new FileInputStream(new File(xmlfile)));
		this.xmlfile = xmlfile;
	}

	public int getChildCount(String parentTag, int parentIndex, String childTag)
	{
		NodeList childList;
		int i=0;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			childList = parent.getElementsByTagName(childTag);
			i = childList.getLength();
		} catch (Exception e) {
			log.info(e);
			System.out.println(e);
		}
		return i;
	}

	public int getSuperChildCount(String parentTag, int parentIndex, String childTag,int childIndex,String superchildTag)
	{
		NodeList childList,superchildlist;
		int i=0;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			childList = parent.getElementsByTagName(childTag);
			Element child = (Element) childList.item(childIndex);
			superchildlist = child.getElementsByTagName(superchildTag);
			i = superchildlist.getLength();
		} catch (Exception e) {
			log.info(e);
			System.out.println(e);
		}
		return i;
	}

	public int getcount(String parentTag)
	{
		int i=0;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			i = list.getLength();
		} catch (Exception e) {
			log.info(e);
			System.out.println(e);
		}
		return i;
	}

	public String getChildValue(String parentTag, int parentIndex, String childTag,int childIndex)
	{
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			NodeList childList = parent.getElementsByTagName(childTag);
			Element field = (Element) childList.item(childIndex);
			Node child = field.getFirstChild();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			}
		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return "";
	}

	public String getChildValue1(String parentTag, int parentIndex, String childTag,
			int childIndex)
	{
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			NodeList childList = parent.getElementsByTagName(childTag);
			Element field = (Element) childList.item(childIndex);
			Node child = field.getLastChild();
			//			NamedNodeMap child1 = field.getAttributes();
			//			child1.getLength();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			}
		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return "";
	}
	public String getChildValuewithtag(String parentTag, int parentIndex, String childTag,
			int childIndex)
	{
		String str = "";
		String s1 = "";
		String s2 = "";
		String[] sary=null;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			NodeList childList = parent.getElementsByTagName(childTag);
			Element field = (Element) childList.item(childIndex);
			field.getElementsByTagName("sub");
			Node child = field.getFirstChild();
			s1 = child.toString();
//			s1 = s1.replaceFirst("[", "");
			sary = s1.split(":");
			if(sary[0].trim().equalsIgnoreCase("[#text")&&sary.length>1){
//				child.getTextContent();
				str = str+child.getTextContent();
			}
			System.out.println(child);
	//		child.get
			while(child.getNextSibling()!=null){
				child  = child.getNextSibling();
				s1 = child.toString();
				sary = s1.split(":");
				if(sary[0].trim().equalsIgnoreCase("[#text")){
					if(sary.length>1)
					str = str+child.getTextContent();
				}else{
					
					if(sary[0].trim().equalsIgnoreCase("[sup")){    //sub
						str = str+"<sup>"+child.getTextContent()+"</sup>";
					}else 
						if(sary[0].trim().equalsIgnoreCase("[sub")){    //sub
						str = str+"<sup>"+child.getTextContent()+"</sup>";
					}else{
					str = str+child.getTextContent();
					}
				}
				 System.out.println(child.toString()); 
				 System.out.println(child.getTextContent());
			}
			System.out.print(childList.getLength());
			Node sibl  = child.getNextSibling();

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return str;
	}
	
	public String getChildValuewithtag2(String parentTag, int parentIndex, String childTag,
			int childIndex)
	{
		String str = "";
		String s1 = "";
		String s2 = "";
		boolean startadd = false;
		String[] sary=null;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			NodeList childList = parent.getElementsByTagName(childTag);
			Element field = (Element) childList.item(childIndex);
//			field.getElementsByTagName("sub");
			Node child = field.getFirstChild();
			s1 = child.toString();
//			s1 = s1.replaceFirst("[", "");
			sary = s1.split(":");
			if(sary[0].trim().equalsIgnoreCase("[#text")&&sary.length>1){
//				child.getTextContent();
				str = str+child.getTextContent();
			}
			System.out.println(child);
	//		child.get
			while(child.getNextSibling()!=null){
				child  = child.getNextSibling();
				s1 = child.toString();
				sary = s1.split(":");
				if(sary[0].trim().equalsIgnoreCase("[#text")){
					if(sary.length>1&&startadd){
					str = str+child.getTextContent();
					}
					//   person-group
				}else{
					
					if(sary[0].trim().equalsIgnoreCase("[string-name")||sary[0].trim().equalsIgnoreCase("[pub-id")
							||sary[0].trim().equalsIgnoreCase("[article-title")||sary[0].trim().equalsIgnoreCase("[source")
							||sary[0].trim().equalsIgnoreCase("[year")||sary[0].trim().equalsIgnoreCase("[volume")
							||sary[0].trim().equalsIgnoreCase("[surname")||sary[0].trim().equalsIgnoreCase("[given-names")
							||sary[0].trim().equalsIgnoreCase("[middlename")||sary[0].trim().equalsIgnoreCase("[person-group")){
//						str = str+child.getTextContent();
					}else{
						startadd = true;
						s2 = child.getTextContent();
						if(!s2.trim().equalsIgnoreCase(",")){
							str = str+child.getTextContent();;
						}
					}
				}
				 System.out.println(child.toString()); 
				 System.out.println(child.getTextContent());
			}
			System.out.print(childList.getLength());
	//		Node sibl  = child.getNextSibling();

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
	int i1 =	str.indexOf(')');
	if(','== str.charAt(i1-1)){
		str = str.substring(0, i1-1)+str.substring(i1, str.length());
	}
	if(','== str.charAt(i1-2)&&' '== str.charAt(i1-1)){
		str = str.substring(0, i1-2)+str.substring(i1, str.length());
	}
//		str = str.replaceFirst(", )", ")");
		return str.replaceAll("\n", "");
	
	}
	
	public String getTextValue(String parentTag, int parentIndex, String childTag,
			int childIndex)
	{
		String s = "";
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(parentIndex);
			NodeList childList = parent.getElementsByTagName(childTag);
			Element field = (Element) childList.item(childIndex);
			s = field.getTextContent();

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	}

	public String getSuperChildValue(String superparentTag, int superparentIndex,String parentTag, 
			int parentIndex, String childTag,int childIndex)
	{
		try {
			NodeList list = m_doc.getElementsByTagName(superparentTag);
			Element superparent = (Element) list.item(superparentIndex);
			NodeList parentList = superparent.getElementsByTagName(parentTag);
			Element field = (Element) parentList.item(parentIndex);
			NodeList childList = field.getElementsByTagName(childTag);
			Element childfield = (Element)  childList.item(childIndex);
			Node child = childfield.getFirstChild();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			}
		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return "";
	}

	public String getValue(String parentTag, int parentIndex)
	{
		String data = "";
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Element parent = (Element) list.item(0);
			if(parent==null)
				return "";
			NodeList child = parent.getChildNodes();
			for (int i = 0; i < child.getLength(); i++) {
				Node chd = child.item(i);
				if (chd instanceof CharacterData) {
					CharacterData cd = (CharacterData) chd;
					data = data +cd.getData();
				}
			}
		} catch (DOMException e) {
			log.info("error in parentTag = "+parentTag+" xmlfile name is "+xmlfile);
			System.err.println("error in parentTag = "+parentTag+" xmlfile name is "+xmlfile);
		} catch (Exception e) {
			log.info("error in parentTag = "+parentTag);
			System.err.println("error in parentTag = "+parentTag);
		}
		return data;
	}

	public String getAttributeValue(String elementTag, int elementIndex,
			String attributeTag) 
	{
		Element element;
		String s = "";
		try {
			NodeList list = m_doc.getElementsByTagName(elementTag);
			element = (Element) list.item(elementIndex);
			if(element==null)
				return "";
			s = element.getAttribute(attributeTag);
		} catch (Exception e) {
			log.info("error in elementTag = "+elementTag+"attributeTag "+attributeTag+" xmlfile name is "+xmlfile);
			System.err.println("error in elementTag = "+elementTag+"attributeTag "+attributeTag+" xmlfile name is "+xmlfile);

		}
		return s;
	}

	public ArrayList<String> getmultipleValue(String parentTag)
	{
		ArrayList data = new ArrayList<String>();

		int l= 0;
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			l = list.getLength();
			Element parent = null;
			for (int i = 0; i < l; i++) {
				parent = (Element) list.item(i);
				if(parent!=null){
					NodeList child = parent.getChildNodes();
					String strdata = "";
					for (int j = 0; j < child.getLength(); j++) {
						Node chd = child.item(j);
						if (chd instanceof CharacterData) {
							CharacterData cd = (CharacterData) chd;
							strdata = strdata +cd.getData();
						}
						data.add(strdata);
					}
				}
			}

		} catch (DOMException e) {
			log.info("error in parentTag = "+parentTag+" xmlfile name is "+xmlfile);
			System.err.println("error in parentTag = "+parentTag+" xmlfile name is "+xmlfile);
		} catch (Exception e) {
			log.info("error in parentTag = "+parentTag);
			System.err.println("error in parentTag = "+parentTag);
		}
		return data;
	}

	public String getAttributeValue(String parentTag, int parentIndex, String childTag,
			int childIndex,String tagattribute)
	{
		String s = "";
		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
			for (int j = 0; j < authorGrp.getChildNodes().getLength(); j++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(j);
				if(authorGrpChild!= null && authorGrpChild.getNodeName().equalsIgnoreCase("author")&&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(childIndex);
					s = attribute.toString();
					if(s.indexOf(tagattribute)>-1){
						s = s.substring(tagattribute.length(), s.length());
						s = s.replaceAll("=", "");
						s = s.replaceAll("\"", "");
					}
					break;
				}
			}
		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	}

	public String getAttributeValue1(String parentTag, int parentIndex, String childTag,
			String tagattribute,String tagtext)
	{
		String s = "";
		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
			int l = getChildCount(parentTag, parentIndex, childTag);
			for (int i = 0; i < l; i++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(i);
				if(authorGrpChild!= null &&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(0);
					s = attribute.toString();
					if(s.indexOf(tagattribute)>-1){
						s = s.substring(tagattribute.length(), s.length());
						s = s.replaceAll("=", "");
						s = s.replaceAll("\"", "");
						if(s.equalsIgnoreCase(tagtext)){
							s = getTextValue(parentTag, parentIndex, childTag, i);
							break;
						}
					}
				}
			}

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	}


	public String getAttributeValuewithvar(String parentTag, int parentIndex, String childTag,
			String tagattribute,String tagtext,String[] var)
	{
		String s = "";
		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
			int l = getChildCount(parentTag, parentIndex, childTag);
			for (int i = 0; i < l; i++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(i);
				if(authorGrpChild!= null &&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(0);
					s = attribute.toString();
					if(s.indexOf(tagattribute)>-1){
						s = s.substring(tagattribute.length(), s.length());
						s = s.replaceAll("=", "");
						s = s.replaceAll("\"", "");
						if(s.equalsIgnoreCase(tagtext)){
//							s = getTextValue(parentTag, parentIndex, childTag, i);
							s= "";
							for (int j = 0; j < var.length; j++) {
								s =s+  getSuperChildValue(parentTag, parentIndex, childTag, i, var[j], 0);
							}
//							s = getSuperChildValue(parentTag, parentIndex, childTag, i, "year", 0);
//							s = s+ getSuperChildValue(parentTag, parentIndex, childTag, i, "month", 0);
//							s = s+ getSuperChildValue(parentTag, parentIndex, childTag, i, "day", 0);
							break;
						}
					}
					//					
				}
			}

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	} 
	
	public String getAttributeValuewithvar2(String parentTag, int parentIndex, String childTag,
			String tagattribute)
	{
		String s = "";
//		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
			int l = getChildCount(parentTag, parentIndex, childTag);
			for (int i = 0; i < l; i++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(i);
				if(authorGrpChild!= null &&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(0);
					s = attribute.toString();
					s = s.substring(s.indexOf(tagattribute)+tagattribute.length(), s.length()) ;
					s = s.replaceFirst("=", "");
					s = s.replaceAll("\"", "");
					s = s.trim();
						}
			}   

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	} 
	
	public String getAttributeValuewithvar3(String parentTag, int parentIndex, String childTag,int childIndex,
			String tagattribute)
	{
		String s = "";
//		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
			int l = getChildCount(parentTag, parentIndex, childTag);
			for (int i = 0; i <= l; i++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(i);
				if(authorGrpChild!= null &&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(1);
					s = attribute.toString();
					s = s.substring(s.indexOf(tagattribute)+tagattribute.length(), s.length()) ;
					s = s.replaceFirst("=", "");
					s = s.replaceAll("\"", "");
					s = s.trim();
						}
			}   

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	} 
	
	public String getAttributeValuewithvar4(String parentTag, int parentIndex, String childTag,int childIndex,
			String tagattribute)
	{
		String s = "";
		System.out.println();
		try {
			NodeList list = m_doc.getElementsByTagName(parentTag);
			Node authorGrp = list.item(parentIndex);
//			authorGrp.getPrefix()
			int l = getChildCount(parentTag, parentIndex, childTag);
			for (int i = 0; i <= l; i++) {
				Node authorGrpChild = authorGrp.getChildNodes().item(i);
				if(authorGrpChild!= null &&(authorGrpChild.toString().indexOf(childTag)>-1)){
					Attr attribute = (Attr)authorGrpChild.getAttributes().item(0);
					s = attribute.toString();
					s = s.substring(s.indexOf(tagattribute)+tagattribute.length(), s.length()) ;
					s = s.replaceFirst("=", "");
					s = s.replaceAll("\"", "");
					s = s.trim();
						}
			}   

		} catch (DOMException e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}catch (Exception e) {
			log.info("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
			System.err.println("Error in parentTag "+parentTag+" INDEX is "+parentIndex+" childTag "+childTag+" xmlfile name is "+xmlfile);
		}
		return s;
	} 
	
}