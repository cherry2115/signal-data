package FileFilter;

import java.io.File;
import java.io.FilenameFilter;

public class XBPFileFilter implements FilenameFilter {
	
	private String ext;
	
	public XBPFileFilter(String ext) {
		this.ext = "." + ext;
	}

	public boolean accept(File dir, String name) {
		return name.endsWith(ext);
	}

}
